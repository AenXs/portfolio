# Adham Hitham Galalah - Cybersecurity Portfolio

## Overview

This is a personal portfolio website for Adham Hitham Galalah, a cybersecurity professional and penetration tester. The application is built as a Flask web application showcasing professional experience, projects, skills, and contact information in the cybersecurity field. The site features a cybersecurity-themed design with a dark color scheme and green accent colors reminiscent of terminal interfaces.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask's built-in rendering
- **UI Framework**: Bootstrap 5.1.3 for responsive design and components
- **CSS Architecture**: Custom CSS variables for theming with cybersecurity-inspired color palette (dark backgrounds with green accents)
- **Icon System**: Font Awesome 6.0.0 for consistent iconography
- **JavaScript**: Vanilla JavaScript for basic interactivity (smooth scrolling, active navigation states)

### Backend Architecture
- **Web Framework**: Flask 3.1.2 following a simple MVC pattern
- **Routing Strategy**: Function-based views with decorators for each page route
- **Configuration Management**: Environment-based configuration with fallback defaults
- **Error Handling**: Custom error pages for 404 and 500 errors with themed styling

### Application Structure
- **Static Routes**: Six main pages (home, about, experience, projects, skills, contact)
- **Template Inheritance**: Base template pattern with consistent navigation and footer
- **Responsive Design**: Mobile-first approach with Bootstrap grid system
- **SEO Optimization**: Proper title tags and semantic HTML structure

### Deployment Architecture
- **WSGI Server**: Gunicorn 21.2.0 for production deployment
- **Development Server**: Flask's built-in development server with debug mode
- **Port Configuration**: Environment variable-based port configuration with default fallback
- **Static File Serving**: Flask's static file handling for CSS, JavaScript, and assets

## External Dependencies

### Python Packages
- **Flask 3.1.2**: Core web framework for routing, templating, and request handling
- **Gunicorn 21.2.0**: Production-ready WSGI HTTP server for deployment

### Frontend Libraries
- **Bootstrap 5.1.3**: CSS framework for responsive design and UI components
- **Font Awesome 6.0.0**: Icon library for consistent iconography throughout the site

### Environment Variables
- **SECRET_KEY**: Flask session security (with development fallback)
- **PORT**: Application port configuration (defaults to 5000)
- **DEBUG**: Development mode toggle (defaults to True)

### Hosting Requirements
- **Python Runtime**: Python 3.x environment
- **Static File Hosting**: Capability to serve CSS, JavaScript, and image assets
- **Environment Variable Support**: For production configuration management